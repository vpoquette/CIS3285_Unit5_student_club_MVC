using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Unit5_student_club_MVC.Models;

namespace Unit5_student_club_MVC.Controllers
{
    public class ClubController : Controller
    {
        // Our link to the list of clubs in the Models folder
        IClubCRUDInterface clubRepo = new ClubRepository();

        public ClubController()
        {
            // we are not using this constructor any more
        }


        // GET: ClubController
        public ActionResult Index()
        {
            return View("Index", clubRepo.getAllClub());
        }

        // GET: ClubController/Details/5
        public ActionResult Details(int id)
        {
            return View("Details", clubRepo.getClubById(id));
        }


        // GET: SampleController/Create
        public ActionResult Create()
        {
            // This display the initial view when creating a club
            return View();
        }

        // POST: SampleController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            // This is run after the user clicks the Create button
            // The collection is a map that contains the data fields
            try
            {
                ClubModel newClub = new ClubModel();
                // Retrieve form data using form collection
                newClub.Id = Int32.Parse(collection["Id"]);
                newClub.ClubName = collection["ClubName"];
                newClub.FacultyName = collection["FacultyName"];
                clubRepo.AddClub(newClub);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ClubController/Edit/5
        public ActionResult Edit(int id)
        {
            // This displays the edit view when it is first openned
            // The club that matches the id parameter must be passed to the view
            return View("Edit", clubRepo.getClubById(id));
        }

        // POST: ClubController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            // This is run after the user edits a club
            // The collection is a map that contains the data fields from the view
            try
            {
                ClubModel updatedClub = new ClubModel();
                // Retrieve form data using form collection
                updatedClub.Id = id;
                updatedClub.ClubName = collection["ClubName"];
                updatedClub.FacultyName = collection["FacultyName"];
                clubRepo.UpdateClub(id, updatedClub);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ClubController/Delete/5
        public ActionResult Delete(int id)
        {
            try
            {
                clubRepo.DeleteClub(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return RedirectToAction(nameof(Index));
            }
        }

        // POST: ClubController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
