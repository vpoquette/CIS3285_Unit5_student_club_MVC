using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Unit5_student_club_MVC.Models
{
    public class ClubRepository : IClubCRUDInterface
    {
        static List<ClubModel> myClubs = new List<ClubModel>();

        public ClubRepository()
        {
            if (myClubs.Count == 0)
            {
                // if list is empty, initialize it
                myClubs.Add(new ClubModel(1001, "Music Club", "Bret"));
                myClubs.Add(new ClubModel(1002, "Coding Club", "Kris"));
                myClubs.Add(new ClubModel(1003, "InterVarsity", "Jessica"));
            }

        }

        public List<ClubModel> getAllClub()
        {
            return (myClubs);
        }

        public ClubModel getClubById(int id)
        {
            foreach (ClubModel club in myClubs)
            {
                if (club.Id == id)
                {
                    return (club);
                }
            }
            // if you can't find the correct club return the first one
            return (nullClub());

        }

        private ClubModel nullClub()
        {
            // create a null club
            ClubModel nullClub = new ClubModel(-1, "Null Club", "Bob");
            return nullClub;
        }

        public void AddClub(ClubModel newClub)
        {
            myClubs.Add(newClub);
        }

        public void DeleteClub(int clubID)
        {
            // search the list for the club that matches the club ID
            // DEBT --- Handle case when club id not found and index is -1
            int index = myClubs.FindIndex(club => (club.Id == clubID));
            myClubs.RemoveAt(index);
        }

        public void UpdateClub(int clubId, ClubModel updatedClub)
        {
            // search the list for the club that matches the club ID
            // DEBT --- Handle case when club id not found and index is -1
            int index = myClubs.FindIndex(club => (club.Id == clubId));
            myClubs[index] = updatedClub;
        }
    }
}
