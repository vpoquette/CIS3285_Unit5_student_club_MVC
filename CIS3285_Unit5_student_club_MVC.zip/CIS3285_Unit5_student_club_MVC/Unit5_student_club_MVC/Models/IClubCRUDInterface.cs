using System.Collections.Generic;
namespace Unit5_student_club_MVC.Models
{
    public interface IClubCRUDInterface
    {
        public List<ClubModel> getAllClub();
        public ClubModel getClubById(int clubID);
        public void AddClub(ClubModel newClub);
        public void UpdateClub(int clubID, ClubModel updatedClub);
        public void DeleteClub(int clubID);

    }

}
