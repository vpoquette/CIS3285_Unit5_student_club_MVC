using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace Unit5_student_club_MVC.Models
{
    public class ClubModel
    {
        int id;
        string clubName;
        string facultyName;

        // The Create view needs a parameterless constructor
        public ClubModel()
        {
            //Debt -- create a blank club here
        }

        public ClubModel(int id, string clubName, string facultyName)
        {
            this.id = id;
            this.clubName = clubName;
            this.facultyName = facultyName;
            
        }

        public int Id { get => id; set => id = value; }
        public string ClubName { get => clubName; set => clubName = value; }
        public string FacultyName { get => facultyName; set => facultyName = value; }

    }
}
